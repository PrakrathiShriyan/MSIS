/*#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main(){
clock_t start_time = clock();
for(int i=0; i<10; i++)
	printf("Hello World\n");
clock_t end_time = clock();
double time_taken = ((double)(end_time - start_time))/CLOCKS_PER_SEC;
printf("%f",time_taken);
return 0;
}*/

/*
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define SIZE 100
#define ERROR 1

int main(){
int m,n;
clock_t start_time = clock();
printf("Enter the size of matrix");
scanf("%d %d",&m ,&n );
printf("Enter the elements");
if(m>100||n>100)
{
	printf("ERROR: you exceeded the size");
	return ERROR;
}
int mat[SIZE][SIZE];
for(int i=0; i<m; i++)
{
	for(int j=0; j<n; j++)
	{
		scanf("%d",&mat[i][j]);
	}
}
printf("Matrix to be displayed......\n");
for(int i=0; i<m; i++)
{
	for(int j=0; j<n; j++)
	{
		printf("%d ",mat[i][j]);
	}
	printf("\n");
}
clock_t end_time = clock();
double time_taken = ((double)(end_time - start_time))/CLOCKS_PER_SEC;
printf("%f",time_taken);
return 0;
}*/


#include<stdio.h>
#include<time.h>
#include<omp.h>
#define CONST 2

int main()
{
	int arr[] = {12,34,6,4,7,8,9,60};
	int size = sizeof(arr)/sizeof(arr[0]);
	#pragma omp parallel num_threads(4)
	{
		int tid = omp_get_thread_num();
		#pragma omp for
		for(int i=0; i<size; i++)
		{
			arr[i] *= CONST;
			printf("Thread %d: %d\n",tid,arr[i]);
		}
	}

return 0;
}


//sorting the matrix
/*
#include<stdio.h>
#include<stlib.h>


void flatten(int * matrix,int size)

int main(){
int matrix[3][3] = {{10 21 3},{2  7  1},{12 0  14}};

int row = 3;
int col = 3;
int matrix_size = row*col;

flatten((int *)matrix,size);
 */
