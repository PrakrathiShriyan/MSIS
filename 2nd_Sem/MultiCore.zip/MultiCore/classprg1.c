//WAP to display the m*n matrix, take input from user: 1) dispaly the matrix, 2)print the multiplication of all elements, 3)display negative elements and print a message if no negative elements

#include <stdio.h> 

int main()
{
	int m,n;
	printf("Enter the value of m and n");
	scanf("%d %d",&m, &n);
	
	int a[m][n];
	printf("Enter the elements:");
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			scanf("%d", &a[i][j]);
		}
	}
	
	printf("Displaying the matrix........\n");
	
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	
	double result = 1;
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			result = result*a[i][j];
		}
	}
	
	printf("Multiplication of all elements: %lf\n", result);
	
	int flag = 0;
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			if(a[i][j]<0)
			{
			printf("%d\n",a[i][j]);
			flag = 1;
			}
		}
	}
	
	if(flag == 0)
	{
		printf("NO negative numbers!!!");
	}
	
	return 0;
	
}
