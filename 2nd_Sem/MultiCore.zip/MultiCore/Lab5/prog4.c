/*Q4.
Write a program to find the minimum element in an array in
parallel using OpenMP. Use shared variables for the array
and the minimum value, and private variables for loop
indices.*/
/*
#include<stdio.h>
#include<omp.h>
#define SIZE 5

int main{
	a[SIZE] = {2,7,3,1,9};
	
	#pragma omp parallel for
	
*/

#include <stdio.h>
#include <omp.h>

#define SIZE 10

int main() {
    int arr[SIZE] = {9, 4, 3, 7, 8, 2, 5, 1, 6, 10};
    int min = arr[0]; // Assume the first element as the minimum initially
    int i;

    #pragma omp parallel for shared(arr) private(i) reduction(min:min)
    for (i = 1; i < SIZE; i++) {
        if (arr[i] < min) {
            min = arr[i];
        }
    }

    printf("The minimum element in the array is: %d\n", min);

    return 0;
}


