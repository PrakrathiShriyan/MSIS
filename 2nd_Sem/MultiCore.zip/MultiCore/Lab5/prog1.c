
/*Q1.
Illustrate loop parallelism with the for loop by writing a
program to calculate the sum of an array in parallel using
OpenMP. (Use a shared variable for the result and private
variables for loop indices).*/
/*
#include <omp.h>
#include <stdio.h>
#define SIZE 5

int main()
{	
	int result = 0;
	int a[SIZE] = {1,2,3,4};
	#pragma omp parallel
		for(int i=0; i<SIZE; i++)
		{
			result += a[i];
		}
		
		printf("result %d \n", result); 
	return 0;
}


//Result is 40

*/
	

#include <stdio.h>
#include <omp.h>
#define SIZE 5

int main()
{	
	int result = 0;
	int a[SIZE] = {1,2,3,4};
	#pragma omp parallel for
		for(int i=0; i<SIZE; i++)
		{
			result += a[i];
		}
		
		printf("result %d \n", result); 
	return 0;
}


//Result is 10

