/*Q3.
Create a parallel program to calculate the factorial of a
number using OpenMP. Use a shared variable for the result,
and private variables for loop indices.*/


#include <stdio.h>
#include <omp.h>

int main()
{
	int N = 9;
	int fact = 1;
	
	#pragma omp parallel for reduction(*: fact)
	for(int i=2; i<=N; i++)
	{
		fact = fact * i;
	}
	printf("%d",fact);
	
	return 0;
}

