/*Q2.
Implement a program to calculate the square of each element
in an array in parallel using OpenMP. Use shared variables
for the input array and private variables for the parallel
for loop indices.*/

#include<stdio.h>
#include<omp.h>
#define SIZE 7

int main(){

	int a[SIZE] = {1,2,3,4,5,6,7};
	
	#pragma omp parallel for
		for(int i=0; i<SIZE; i++)
		{
			a[i] *= a[i];
			
		}
		for(int i=0; i<SIZE; i++)
		printf("%d ",a[i]); 
		
		
	return 0;
}

//Result: 1 4 9 16 25 36 49 


/*
#include<stdio.h>
#include<omp.h>
#define SIZE 7

int main(){

	int a[SIZE] = {1,2,3,4,5,6,7};
	
	#pragma omp parallel
		for(int i=0; i<SIZE; i++)
		{
			a[i] *= a[i];
			
		}
		for(int i=0; i<SIZE; i++)
		printf("%d ",a[i]); 
		
		
	return 0;
}

results in incorrect answers
*/
