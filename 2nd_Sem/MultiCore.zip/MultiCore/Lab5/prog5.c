/*Q5.
Implement a program to generate the Fibonacci series in
parallel using OpenMP. Use shared variables for the result
array and private variables for each thread's local
variables.*/
