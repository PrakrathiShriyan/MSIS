/*Q6.
Write a program to transpose a matrix in parallel using
OpenMP. Use shared variables for the input and output
matrices and private variables for loop indices.*/
