/*#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_SIZE 100

// Function to get input matrix from user
void getMatrix(int matrix[MAX_SIZE][MAX_SIZE], int m, int n) {
    printf("Enter matrix elements:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

// Function to count positive, negative, and zero elements in a row
void countRow(int row[MAX_SIZE], int n, int *positive, int *negative, int *zeros) {
    int thread_id = omp_get_thread_num(); // Get thread ID
    for (int i = 0; i < n; i++) {
        if (row[i] > 0)
            (*positive)++;
        else if (row[i] < 0)
            (*negative)++;
        else
            (*zeros)++;
    }
    printf("Thread %d computing Row: Positive=%d, Negative=%d, Zero=%d\n", thread_id, *positive, *negative, *zeros);
}

// Function to find the smallest number in a column
int findMin(int matrix[MAX_SIZE][MAX_SIZE], int m, int col) {
    int min = matrix[0][col];
    int thread_id = omp_get_thread_num(); // Get thread ID
    for (int i = 1; i < m; i++) {
        if (matrix[i][col] < min)
            min = matrix[i][col];
    }
    printf("Thread %d computing Column %d: Smallest=%d\n", thread_id, col+1, min);
    return min;
}

int main() {
    int m, n;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &m, &n);

    if (m > MAX_SIZE || n > MAX_SIZE) {
        printf("Matrix size exceeds maximum limit.\n");
        return 1;
    }

    int matrix[MAX_SIZE][MAX_SIZE];

    getMatrix(matrix, m, n);

    double start_time = omp_get_wtime();

    // Parallel calculation of row statistics
    printf("Row statistics:\n");
    #pragma omp parallel for
    for (int i = 0; i < m; i++) {
        int positive = 0, negative = 0, zeros = 0;
        countRow(matrix[i], n, &positive, &negative, &zeros);
    }

    // Parallel calculation of column statistics
    printf("\nColumn statistics:\n");
    #pragma omp parallel for
    for (int j = 0; j < n; j++) {
        findMin(matrix, m, j);
    }

    double end_time = omp_get_wtime();
    printf("Execution time: %f seconds\n", end_time - start_time);

    return 0;
}*/


#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_SIZE 100

// Function to get input matrix from user
void getMatrix(int matrix[MAX_SIZE][MAX_SIZE], int m, int n) {
    printf("Enter matrix elements:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}								
/*
2  0 -2
5  0  0
1 -3 -4
1 -3  0

n = 3
m = 4	*/																	

// Function to count positive, negative, and zero elements in a row
void countRow(int row[MAX_SIZE], int n) {
int i;
    int positive = 0, negative = 0, zeros = 0;
    int thread_id = omp_get_thread_num(); // Get thread ID
    for (int i = 0; i < n; i++) {
        if (row[i] > 0)
            (positive)++;
        else if (row[i] < 0)
            (negative)++;
        else
            (zeros)++;
    }
    printf("Thread %d computing Row %d: Positive=%d, Negative=%d, Zero=%d\n", thread_id, thread_id+1,positive, negative, zeros);
}


// Function to find the smallest number in a column
int findMin(int matrix[MAX_SIZE][MAX_SIZE], int m, int col) {
    int min = matrix[0][col];
    int thread_id = omp_get_thread_num(); // Get thread ID
    for (int i = 1; i < m; i++) {
        if (matrix[i][col] < min)
            min = matrix[i][col];
    }
    printf("Thread %d computing Column %d: Smallest=%d\n", thread_id, col+1, min);
    return min;
}

int main() {
    int m, n;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &m, &n);

    if (m > MAX_SIZE || n > MAX_SIZE) {
        printf("Matrix size exceeds maximum limit.\n");
        return 1;
    }

    int matrix[MAX_SIZE][MAX_SIZE];

    getMatrix(matrix, m, n);

 //   double start_time = omp_get_wtime();
    clock_t start_time = clock();
    
/*here using this block, each thread will execute for each column, hence m*m statements 
     // Parallel calculation of row statistics
    printf("Row statistics:\n");
    #pragma omp parallel num_threads(m)
    for (int i = 0; i < m; i++) {
        
        countRow(matrix[i], n);
    }*/

    // Parallel calculation of row statistics
    printf("Row statistics:\n");
    #pragma omp parallel for
    for (int i = 0; i < m; i++) {
        
        countRow(matrix[i],n);
    }
    
/* here using this block, each thread will execute for each column, hence n*n statements 
    // Parallel calculation of column statistics
    printf("\nColumn statistics:\n");
    #pragma omp parallel num_threads(n)
    for (int j = 0; j < n; j++) {
        findMin(matrix, m, j);
    }*/
    
      // Parallel calculation of column statistics
    printf("\nColumn statistics:\n");
    #pragma omp parallel for
    for (int j = 0; j < n; j++) {
        findMin(matrix, m, j);
    }

    //double end_time = omp_get_wtime();
    //printf("Execution time: %f seconds\n", end_time - start_time);
    
    clock_t end_time = clock();
    double time_taken = ((double)(end_time - start_time))/CLOCKS_PER_SEC;
    printf("Time taken: %f",time_taken);

    return 0;
}


