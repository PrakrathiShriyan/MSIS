/*#include <stdio.h>
#include <stdlib.h>

// Function to compare two integers (used by qsort)
int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

// Function to sort each row of the matrix
void sortMatrixRows(int *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        qsort(matrix + i * cols, cols, sizeof(int), compare);
    }
}

// Function to print the matrix
void printMatrix(int *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", *((matrix + i * cols) + j));
        }
        printf("\n");
    }
}

int main() {
    int matrix[3][3] = {
        {9, 5, 7},
        {4, 8, 2},
        {3, 6, 1}
    };
    int rows = 3;
    int cols = 3;

    printf("Original Matrix:\n");
    printMatrix((int *)matrix, rows, cols);

    sortMatrixRows((int *)matrix, rows, cols);

    printf("\nMatrix after sorting each row in ascending order:\n");
    printMatrix((int *)matrix, rows, cols);

    return 0;
}*/

/*
#include <stdio.h>
#include <stdlib.h>

// Function to compare two integers (used by qsort)
int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

// Function to print the matrix
void printMatrix(int *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", *((matrix + i * cols) + j));
        }
        printf("\n");
    }
}

int main() {
    int matrix[3][3] = {
        {9, 5, 7},
        {4, 8, 2},
        {3, 6, 1}
    };
    int rows = 3;
    int cols = 3;

    int total_elements = rows * cols;
    int flattened_matrix[total_elements];

    // Flatten the matrix into a one-dimensional array
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            flattened_matrix[i * cols + j] = matrix[i][j];
        }
    }

    // Sort the flattened array
    qsort(flattened_matrix, total_elements, sizeof(int), compare);

    // Reshape the sorted array back into a matrix
    int index = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = flattened_matrix[index++];
        }
    }

    printf("Original Matrix:\n");
    printMatrix((int *)matrix, rows, cols);

    printf("\nMatrix after sorting in ascending order:\n");
    printMatrix((int *)matrix, rows, cols);

    return 0;
}*/

#include <stdio.h>
#define SIZE 100

// Function to sort the flattened matrix using bubble sort
void bubbleSort(int *arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
            	int temp = arr[j];
            	arr[j]=arr[j+1];
            	arr[j+1]=temp;
            }
        }
    }
}

// Function to print the matrix
void printMatrix(int matrix[][SIZE], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            //printf("%d ", *((matrix + i * cols) + j));
            printf("% d", matrix[i][j]);       
        }
        printf("\n");
    }
}

int main() {
    /*int matrix[3][3] = {
        {9, 5, 7},
        {4, 8, 2},
        {3, 6, 1}
    };*/
    int rows, cols;
    printf("Enter the size of matrix\n");
    scanf("%d %d",&rows,&cols);
    //int rows = 3;
    //int cols = 3;
    int matrix[SIZE][SIZE];
    
    printf("Enter the elements\n");
    
    for(int i=0; i<rows; i++)
    {
    	for(int j=0; j<cols; j++)
    	{
     		scanf("%d",&matrix[i][j]);
     	}
    }

    int total_elements = rows * cols;
    int flattened_matrix[total_elements];
    
    printf("Original Matrix:\n");
    printMatrix(matrix, rows, cols);
    /*for(int i=0; i<rows; i++)
    {
    	for(int j=0; j<cols;j++)
    	{
    		printf("%d ",matrix[i][j]);
    	}
    	printf("\n");
    }*/

    // Flatten the matrix into a one-dimensional array
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            flattened_matrix[i * cols + j] = matrix[i][j];
        }
    }

    // Sort the flattened array using bubble sort
    bubbleSort(flattened_matrix, total_elements);

    // Reshape the sorted array back into a matrix
    int index = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = flattened_matrix[index++];
        }
    }


    printf("\nMatrix after sorting in ascending order (using bubble sort):\n");
    printMatrix(matrix, rows, cols);
    /*for(int i=0; i<rows; i++)
    {
    	for(int j=0; j<cols;j++)
    	{
    		printf("%d ",matrix[i][j]);
    	}
    	printf("\n");
    }*/

    return 0;
}

//(int*)[] to (int*)
