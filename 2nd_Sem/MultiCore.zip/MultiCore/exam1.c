#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Function to get input matrix from user
void getMatrix(int **matrix, int m, int n) {
    printf("Enter matrix elements:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

// Function to count positive, negative, and zero elements in a row
void countRow(int *row, int n, int *positive, int *negative, int *zeros) {
    for (int i = 0; i < n; i++) {
        if (row[i] > 0)
            (*positive)++;
        else if (row[i] < 0)
            (*negative)++;
        else
            (*zeros)++;
    }
}

// Function to find the smallest number in a column
int findMin(int **matrix, int m, int col) {
    int min = matrix[0][col];
    for (int i = 1; i < m; i++) {
        if (matrix[i][col] < min)
            min = matrix[i][col];
    }
    return min;
}

int main() {
    int m, n;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &m, &n);

    int **matrix = (int **)malloc(m * sizeof(int *));
    for (int i = 0; i < m; i++) {
        matrix[i] = (int *)malloc(n * sizeof(int));
    }

    getMatrix(matrix, m, n);

    // Sequential calculation of row statistics
    printf("Row statistics:\n");
    for (int i = 0; i < m; i++) {
        int positive = 0, negative = 0, zeros = 0;
        countRow(matrix[i], n, &positive, &negative, &zeros);
        printf("Row %d: Positive=%d, Negative=%d, Zero=%d\n", i+1, positive, negative, zeros);
    }

    // Sequential calculation of column statistics
    printf("\nColumn statistics:\n");
    for (int j = 0; j < n; j++) {
        printf("Column %d: Smallest=%d\n", j+1, findMin(matrix, m, j));
    }

    // Free dynamically allocated memory
    for (int i = 0; i < m; i++) {
        free(matrix[i]);
    }
    free(matrix);

    return 0;
}

