/*(ii) Modify your code so that you convert the code into a 
function called sort(). Signature of matrix_sort() can be 
as below:
int sort(int mat[][], int rows, int cols). 
Let the return value of sort() be zero always.
Write a suitable main() which invokes sort() and observe your results.*/

#include<stdio.h>

int sort(int mat[][], int rows, int cols)
{
	for(int i=0; i < rows*cols-1; i++)
	{
		for(int j=0; j< rows*cols-i-1; j++)
		{
			if(mat[j/cols][j%cols] < mat[(j+1)/cols][(j+1)%cols]) 
			{
				int temp = mat[j/cols][j%cols];
				mat[j/cols][j%cols] = mat[(j+1)/cols][(j+1)%cols];
				mat[(j+1)/cols][(j+1)%cols] = temp;
			}
				 
		}
	}
}

int main(){
	int m,n;
	printf("Enter the values of m and n");
	scanf("%d %d",&m, &n);
	
	int mat[m][n];
	
	printf("Enter the elements");
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			scanf("%d",&mat[i][j]);
		}
	}	
	
	printf("Sorted Array:\n");
	
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			printf("%d ",mat[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
