/*(ii) Modify your code so that you convert the code into a 
function called search(). 
 Signature of search() can be as below:
 int search(int mat[][], int rows, int cols, int 
key). 
 Let the search function return 0 on finding the key, 
and return -1 if the key is not present in the 
matrix. Write a suitable main function which invokes 
search() and observe your results.*/
/*
#include<stdio.h>
#define r 10
#define c 10


int search(int a[r][c], int rows, int cols, int key)
{
	int flag = 0;
	for(int i=0; i<rows; i++)
	{
		for(int j=0; j<cols; j++)
		{
			if(a[i][j] == key)	
				return 0;//we can keep this since when it returns, it will come out of function
		}

	}
	return -1;
}


int main()
{
	int a[row][col];
	int m,n;
	
	printf("Enter the value of m and n:");
	scanf("%d %d",&m,&n);
	
	printf("Enter the elements of the matrix:\n");
	
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			scanf("%d",&a[i][j]); 
		}
	}
	
	int s, found;
	printf("Enter the element to search:");
	scanf("%d",&s);
	
	found = search(a, m, n, s);
	
	if(found == 0)
		printf("Found");
	
	else
		printf("Not found");
	
	return 0;
}

*/
/*#include <stdio.h>

int search(int *a[][], int row, int cols, int key)
{
    int flag = 0;

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            if (a[i][j] == key)
            {
                flag = 1;
                return 0;
            }
        }
    }

    if (flag == 0)
        return -1;
}

int main()
{
    int m, n;

    printf("Enter the value of m and n:");
    scanf("%d %d", &m, &n);

    int a[m][n];

    printf("Enter the elements of the matrix:\n");

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &a[i][j]);
        }
    }

    int s;

    printf("Enter the element to search:");
    scanf("%d", &s);

    int result = search(&a, m, n, s);

    if (result == 0)
    {
        printf("Element found.\n");
    }
    else
    {
        printf("Element not found.\n");
    }

    return 0;
}*/



#include <stdio.h>

int search(int *a, int row, int cols, int key)
{
    int flag = 0;

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            if (*(a + i * cols + j) == key) //i*cols becoz we have to jump col times to get another row
            {
                flag = 1;
                return 0;
            }
        }
    }

    if (flag == 0)
        return -1;
}

int main()
{
    int m, n;

    printf("Enter the value of m and n:");
    scanf("%d %d", &m, &n);

    int a[m][n];

    printf("Enter the elements of the matrix:\n");

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &a[i][j]);
        }
    }

    int s;

    printf("Enter the element to search:");
    scanf("%d", &s);

    int result = search(&a[0][0], m, n, s);

    if (result == 0)
    {
        printf("Element found.\n");
    }
    else
    {
        printf("Element not found.\n");
    }

    return 0;
}
