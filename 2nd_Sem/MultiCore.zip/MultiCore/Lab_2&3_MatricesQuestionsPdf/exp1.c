/*(i) Write a C program to search for a given element in a
matrix. The program should take a matrix and a target 
element as input, and it should output whether the element 
is present in the matrix or not.*/

#include<stdio.h>

int main()
{
	int m,n;
	printf("Enter the value of m and n:");
	scanf("%d %d",&m,&n);
	
	int a[m][n];
	
	printf("Enter the elements of the matrix:\n");
	
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<m; j++)
		{
			scanf("%d",&a[i][j]); 
		}
	}
	
	int s;
	printf("Enter the element to search:");
	scanf("%d",&s);
	
	int flag = 0;
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<m; j++)
		{
			if(a[i][j] == s)	
				flag = 1;
		}
		if(flag == 1)
		{
			printf("Element is present!!");
			break;
		}
	}
	if(flag == 0) printf("Element not present :(");
return 0;
}
