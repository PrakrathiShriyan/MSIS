//2. (i) Write a C program to sort the elements of a matrix. The program should take a matrix as input and display the sorted matrix.

#include<stdio.h>

int main(){
	int m,n;
	printf("Enter the values of m and n");
	scanf("%d %d",&m, &n);
	
	int arr[m][n];
	
	printf("Enter the elements");
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			scanf("%d",&arr[i][j]);
		}
	}
	
	//int temp = a[0][0];
	for(int i=0; i < m*n-1; i++)
	{
		for(int j=0; j< m*n-i-1; j++)
		{
			if(arr[j/n][j%n] < arr[(j+1)/n][(j+1)%n]) 
			{
				int temp = arr[j/n][j%n];
				arr[j/n][j%n] = arr[(j+1)/n][(j+1)%n];
				arr[(j+1)/n][(j+1)%n] = temp;
			}
				 
		}
	}
	
	
	printf("Sorted Array:\n");
	
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			printf("%d ",arr[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
