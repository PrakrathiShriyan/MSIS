/*2. Consider an integer matrix of order n*m. Create three threads using omp where one of them displays the matrix elemrnts, the second one reverses each matrix element and the third one cubes every element in place. 
Use critical section or omp lock routines to ensure that the threads do not get into race situation.*/

#include <stdio.h>
#include <omp.h>

#define N 3
#define M 3

// Define a lock
omp_lock_t lock;

void displayMatrix(int matrix[N][M]) {
    printf("Matrix elements:\n");
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

void reverseMatrix(int matrix[N][M]) {
    // Reverse each matrix element
    #pragma omp parallel for collapse(2)
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            omp_set_lock(&lock);
            matrix[i][j] *= -1;
            omp_unset_lock(&lock);
        }
    }
}

void cubeMatrix(int matrix[N][M]) {
    // Cube each matrix element
    #pragma omp parallel for collapse(2)
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            omp_set_lock(&lock);
            matrix[i][j] *= matrix[i][j] * matrix[i][j];
            omp_unset_lock(&lock);
        }
    }
}

int main() {
    int matrix[N][M];

    // Initialize matrix
    int count = 1;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            matrix[i][j] = count++;
        }
    }

    // Initialize the lock
    omp_init_lock(&lock);

    // Create threads
    #pragma omp parallel num_threads(3)
    {
        int thread_id = omp_get_thread_num();
        if (thread_id == 0) {
            displayMatrix(matrix);
        } else if (thread_id == 1) {
            reverseMatrix(matrix);
        } else if (thread_id == 2) {
            cubeMatrix(matrix);
        }
    }

    // Destroy the lock
    omp_destroy_lock(&lock);

    return 0;
}

