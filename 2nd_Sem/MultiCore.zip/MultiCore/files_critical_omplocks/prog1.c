/*1. Write a program which creates 3 threads of which one reads a text file of your current directory and counts the total lines, characters and blanks. Another threads appends a message "hello world" to the file. Another file appends five lines of user provided text to the same file. 
Use critical section or omp lock routines to ensure that the threads do not get into race situation.*/

#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

// Define a lock
omp_lock_t lock;

void countLinesCharsBlanks(const char *filename, int *lines, int *chars, int *blanks) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Unable to open file %s\n", filename);
        return;
    }

    char ch;
    *lines = *chars = *blanks = 0;

    while ((ch = fgetc(file)) != EOF) {
        (*chars)++;
        if (ch == '\n') {
            (*lines)++;
        } else if (ch == ' ') {
            (*blanks)++;
        }
    }

    fclose(file);
}

void appendHelloWorld(const char *filename) {
    FILE *file = fopen(filename, "a");
    if (file == NULL) {
        printf("Error: Unable to open file %s\n", filename);
        return;
    }

    omp_set_lock(&lock);
    fprintf(file, "hello world\n");
    omp_unset_lock(&lock);

    fclose(file);
}

void appendUserText(const char *filename, const char *text) {
    FILE *file = fopen(filename, "a");
    if (file == NULL) {
        printf("Error: Unable to open file %s\n", filename);
        return;
    }

    omp_set_lock(&lock);
    for (int i = 0; i < 5; i++) {
        fprintf(file, "%s\n", text);
    }
    omp_unset_lock(&lock);

    fclose(file);
}

int main() {
    int lines, chars, blanks;
    const char *filename = "test.txt";
    const char *user_text = "User provided text";

    // Initialize the lock
    omp_init_lock(&lock);

    // Create threads
    #pragma omp parallel num_threads(3)
    {
        int thread_id = omp_get_thread_num();
        if (thread_id == 0) {
            countLinesCharsBlanks(filename, &lines, &chars, &blanks);
            printf("Lines: %d, Characters: %d, Blanks: %d\n", lines, chars, blanks);
        } else if (thread_id == 1) {
            appendHelloWorld(filename);
        } else if (thread_id == 2) {
            appendUserText(filename, user_text);
        }
    }

    // Destroy the lock
    omp_destroy_lock(&lock);

    return 0;
}

