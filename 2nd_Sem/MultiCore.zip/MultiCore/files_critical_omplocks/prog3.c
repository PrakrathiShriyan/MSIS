/*3. Define and populate an array of size n with double or floating point numbers. Create four threads using omp where one of them displays the array elements, the second one counts the total sum of the numbers, the third one finds the maximum element in the array, and the fourth one squares every element. 
Use critical section or omp lock routines to ensure that the threads do not get into race situation.*/

#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define SIZE 10

// Define a lock
omp_lock_t lock;

void displayArray(double *arr, int n) {
    printf("Array elements:\n");
    for (int i = 0; i < n; i++) {
        printf("%.2f ", arr[i]);
    }
    printf("\n");
}

double calculateSum(double *arr, int n) {
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    return sum;
}

double findMax(double *arr, int n) {
    double max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}

void squareElements(double *arr, int n) {
    for (int i = 0; i < n; i++) {
        arr[i] *= arr[i];
    }
}

int main() {
    double arr[SIZE];
    int i;

    // Initialize array
    for (i = 0; i < SIZE; i++) {
        arr[i] = i + 1; // Assigning some values for demonstration
    }

    // Initialize the lock
    omp_init_lock(&lock);

    // Create threads
    #pragma omp parallel num_threads(4)
    {
        int thread_id = omp_get_thread_num();

        // Display array elements
        if (thread_id == 0) {
            omp_set_lock(&lock);
            displayArray(arr, SIZE);
            omp_unset_lock(&lock);
        }

        // Calculate total sum of array elements
        else if (thread_id == 1) {
            double sum;
            omp_set_lock(&lock);
            sum = calculateSum(arr, SIZE);
            printf("Total sum of array elements: %.2f\n", sum);
            omp_unset_lock(&lock);
        }

        // Find maximum element in the array
        else if (thread_id == 2) {
            double max;
            omp_set_lock(&lock);
            max = findMax(arr, SIZE);
            printf("Maximum element in the array: %.2f\n", max);
            omp_unset_lock(&lock);
        }

        // Square every element in the array
        else if (thread_id == 3) {
            omp_set_lock(&lock);
            squareElements(arr, SIZE);
            printf("Array elements squared.\n");
            omp_unset_lock(&lock);
        }
    }

    // Destroy the lock
    omp_destroy_lock(&lock);

    return 0;
}

