/*Example(simple program without the seed):*/
#include <stdio.h>
#include <stdlib.h>
int main() {
 // Without seeding the random number generator
 // The sequence of random numbers will be the same on each run within the same second
 // Generate a random number between 0 and 9
 int randomNumber = rand() % 10;
 // Print the random number
 printf("Random Number between 0 and 9: %d\n",randomNumber);
 return 0;
}
