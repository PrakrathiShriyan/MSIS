/*To display the current time in C, you can use the time() 
function to obtain the current time in seconds since the 
epoch and then use the ctime() function to convert it to a 
human-readable string. 
Program:*/

#include <stdio.h>
#include <time.h>
int main() {
 // Get the current time
 time_t currentTime;
 time(&currentTime);
 // Convert the time to a string and display
 char* timeString = ctime(&currentTime);
 printf("Current Time: %s", timeString);
 return 0;
}

