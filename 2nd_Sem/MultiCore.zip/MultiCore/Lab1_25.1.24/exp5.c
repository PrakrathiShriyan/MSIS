/*Finding the current time using necessary c library:
To use time_t in your programs, you include the <time.h> 
header, which provides the declaration of time_t and 
various functions for working with time values. For 
example:*/
#include <stdio.h>
#include <time.h>
int main() {
 time_t currentTime; // defining a variable of type time_t
 time(&currentTime); // calling time function on the variable
 printf("Current time: %ld\n", currentTime);
 return 0;
}

