/*Write a multithreaded program that will find the repetition of a
number within a n*n order square matrix. (Let the intilization of
the matrix be done within the parallel region by just one thread.
Let the number to be searched be input by the user before
entering the parallel region).*/

#include <stdio.h>
#include <omp.h>

#define MAX_SIZE 10

void initializeMatrix(int matrix[MAX_SIZE][MAX_SIZE], int n) {
    // Initialize the matrix with some values (for demonstration purposes)
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matrix[i][j] = (i + j) % 5;  // Initializing with some repeating numbers
        }
    }
}

int main() {
    int n, search_number, repetitions = 0;
    int matrix[MAX_SIZE][MAX_SIZE];

    // User input
    printf("Enter the size of the square matrix: ");
    scanf("%d", &n);

    printf("Enter the number to search for: ");
    scanf("%d", &search_number);

    // Initialize matrix
    initializeMatrix(matrix, n);

    // Search for the number in parallel
    #pragma omp parallel for reduction(+:repetitions)
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (matrix[i][j] == search_number) {
                repetitions++;
            }
        }
    }

    // Print result
    printf("Number of repetitions of %d in the matrix: %d\n", search_number, repetitions);

    return 0;
}

