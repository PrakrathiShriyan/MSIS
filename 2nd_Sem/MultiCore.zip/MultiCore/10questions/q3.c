/*#include <stdio.h>
#include <omp.h>

#define SIZE 10

void addArrays(int *array1, int *array2, int *result, int start, int end, int thread_num) {
    for (int i = start; i < end; i++) {
        result[i] = array1[i] + array2[i];
        printf("Thread %d added elements at index %d\n", thread_num, i);
    }
}

void multiplyArrays(int *array1, int *array2, int *result, int start, int end, int thread_num) {
    for (int i = start; i < end; i++) {
        result[i] = array1[i] * array2[i];
        printf("Thread %d multiplied elements at index %d\n", thread_num, i);
    }
}

int main() {
    int array1[SIZE], array2[SIZE], add_result[SIZE], multiply_result[SIZE];
    int chunk_size = SIZE / 4;

    // Initialize arrays
    for (int i = 0; i < SIZE; i++) {
        array1[i] = i;
        array2[i] = i * 2;
    }
    
    for(int i=0; i<SIZE; i++)
    {
    printf("%d ",array1[i]);
    }
    
    printf("\n");
    
    for(int i=0; i<SIZE; i++)
    {
    printf("%d ",array2[i]);
    }
    
    // Parallel computation using OpenMP
    #pragma omp parallel num_threads(2)
    {
        int thread_num = omp_get_thread_num();
        int start = thread_num * chunk_size;
        int end = start + chunk_size;

        if (thread_num == 0) {
            addArrays(array1, array2, add_result, start, end, thread_num);
        } else {
            multiplyArrays(array1, array2, multiply_result, start, end, thread_num);
        }
    }

    // Print the result of addition
    printf("\nAddition Result:\n");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", add_result[i]);
    }
    printf("\n");

    // Print the result of multiplication
    printf("\nMultiplication Result:\n");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", multiply_result[i]);
    }
    printf("\n");

    return 0;
}*/


#include <stdio.h>
#include <omp.h>

#define SIZE 10

void addArrays(int *array1, int *array2, int *result, int thread_num) {
    #pragma omp parallel for
    for (int i = 0; i < SIZE; i++) {
        result[i] = array1[i] + array2[i];
        printf("Thread %d added elements at index %d\n", thread_num, i);
    }
}

void multiplyArrays(int *array1, int *array2, int *result, int thread_num) {
    #pragma omp parallel for
    for (int i = 0; i < SIZE; i++) {
        result[i] = array1[i] * array2[i];
        printf("Thread %d multiplied elements at index %d\n", thread_num, i);
    }
}

int main() {
    int array1[SIZE], array2[SIZE], add_result[SIZE], multiply_result[SIZE];

    // Initialize arrays
    for (int i = 0; i < SIZE; i++) {
        array1[i] = i;
        array2[i] = i * 2;
    }
    
    
    for(int i=0; i<SIZE; i++)
    {
    printf("%d ",array1[i]);
    }
    
    printf("\n");
    
    for(int i=0; i<SIZE; i++)
    {
    printf("%d ",array2[i]);
    }
    
    printf("\n");

    // Parallel computation using OpenMP
    #pragma omp parallel sections
    {
        #pragma omp section
        {
            int thread_num = omp_get_thread_num();
            addArrays(array1, array2, add_result, thread_num);
        }

        #pragma omp section
        {
            int thread_num = omp_get_thread_num();
            multiplyArrays(array1, array2, multiply_result, thread_num);
        }
    }

    // Print the result of addition
    printf("\nAddition Result:\n");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", add_result[i]);
    }
    printf("\n");

    // Print the result of multiplication
    printf("\nMultiplication Result:\n");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", multiply_result[i]);
    }
    printf("\n");

    return 0;
}

