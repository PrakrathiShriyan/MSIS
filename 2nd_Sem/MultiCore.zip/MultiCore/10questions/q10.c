/*. Write a mulithreaded program to multiply every element in a
matrix with a constant number.
The numbers in even rows should be multiplied by even numbered
threads, and the number in odd rows should be multiplied by odd
numbered threads. Print the thread number after each
multiplication.*/


#include <stdio.h>
#include <omp.h>

#define MAX_ROWS 10
#define MAX_COLS 10
#define CONSTANT 2

int main() {
    int matrix[MAX_ROWS][MAX_COLS];
    int rows, cols;

    // User input for matrix dimensions
    printf("Enter number of rows: ");
    scanf("%d", &rows);
    printf("Enter number of columns: ");
    scanf("%d", &cols);

    // Matrix input
    printf("Enter elements of the matrix:\n");
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }

    // Parallel computation using OpenMP
    #pragma omp parallel for
    for (int i = 0; i < rows; i++) {
        int thread_num = omp_get_thread_num();
        if ((i % 2 == 0 && thread_num % 2 == 0) || (i % 2 != 0 && thread_num % 2 != 0)) {
            // Multiplication only if the row number and thread number are both even or both odd
            for (int j = 0; j < cols; j++) {
                matrix[i][j] *= CONSTANT;
                printf("Thread %d multiplied element at row %d, column %d\n", thread_num, i, j);
            }
        }
    }

    // Print the modified matrix
    printf("\nModified matrix:\n");
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}

