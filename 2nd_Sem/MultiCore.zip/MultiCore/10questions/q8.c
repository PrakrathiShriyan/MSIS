/*Write a multithreaded program to compute the sum of all the
elements in a matrix.
Let each thread should determine the partial sum of a column. Let
the number of threads working together be equal to the number
of columns.*/


#include <stdio.h>
#include <omp.h>

#define MAX_ROWS 10
#define MAX_COLS 10

int main() {
    int matrix[MAX_ROWS][MAX_COLS];
    int row_sum[MAX_COLS] = {0}; // Array to store partial sum of each column
    int total_sum = 0;
    int rows, cols;

    // User input for matrix dimensions
    printf("Enter number of rows: ");
    scanf("%d", &rows);
    printf("Enter number of columns: ");
    scanf("%d", &cols);

    // Matrix input
    printf("Enter elements of the matrix:\n");
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }

    // Parallel computation using OpenMP
    #pragma omp parallel num_threads(cols)
    {
        int thread_id = omp_get_thread_num();

        // Each thread computes the partial sum of its corresponding column
        #pragma omp for
        for (int i = 0; i < rows; i++) {
            row_sum[thread_id] += matrix[i][thread_id];
        }
    }

    // Compute the total sum
    for (int i = 0; i < cols; i++) {
        total_sum += row_sum[i];
    }

    // Print the total sum
    printf("Total sum of all elements in the matrix: %d\n", total_sum);

    return 0;
}

