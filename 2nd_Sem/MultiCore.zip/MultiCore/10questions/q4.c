/*Write a multithreaded program to multiply every element in the
array by a constant. The even numbered threads should multiply
the elements in the even indices of the array and the odd
numbered threads should multiply the elements present in the
odd indices of the array. (Assume 0 to be the starting even
index).*/

#include <stdio.h>
#include <omp.h>

#define SIZE 10
#define CONSTANT 2

void multiplyByConstant(int *array, int constant, int thread_num) {
    int start_index = (thread_num % 2 == 0) ? 0 : 1; // Starting index depends on thread number
    #pragma omp parallel for
    for (int i = start_index; i < SIZE; i += 2) {
        array[i] *= constant;
        printf("Thread %d multiplied element at index %d\n", thread_num, i);
    }
}

int main() {
    int array[SIZE];

    // Initialize array
    for (int i = 0; i < SIZE; i++) {
        array[i] = i + 1;
    }

    // Parallel computation using OpenMP
    #pragma omp parallel num_threads(4)
    {
        int thread_num = omp_get_thread_num();
        multiplyByConstant(array, CONSTANT, thread_num);
    }

    // Print the result
    printf("\nResult:\n");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}

