/*Write a multithreaded program to compute the sum of two n*n
square order matrices.
Let the intilization of the matrix be done with in the parallel
region, just by only one thread.*/


#include <stdio.h>
#include <omp.h>

#define MAX_SIZE 10

int main() {
    int n;
    int matrix1[MAX_SIZE][MAX_SIZE];
    int matrix2[MAX_SIZE][MAX_SIZE];
    int sum_matrix[MAX_SIZE][MAX_SIZE];

    // User input for matrix dimensions
    printf("Enter the size of the square matrices: ");
    scanf("%d", &n);

    // Matrix initialization by a single thread within parallel region
    #pragma omp parallel num_threads(1)
    {
        #pragma omp single nowait
        {
            printf("Initializing matrices...\n");
            // Initialize matrices (for demonstration, can be replaced with user input)
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    matrix1[i][j] = i + j;
                    matrix2[i][j] = i - j;
                }
            }
        }
    }

    // Parallel computation using OpenMP for matrix addition
    #pragma omp parallel for collapse(2)
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            sum_matrix[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }

    // Print the sum matrix
    printf("Sum of the matrices:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", sum_matrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}

