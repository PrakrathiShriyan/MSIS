/*Write a multithreaded program that will compare two arrays, and
print all the common elements and their count.*/


#include <stdio.h>
#include <omp.h>

#define SIZE 10

void findCommonElements(int *array1, int *array2, int *common_elements, int *count, int thread_num) {
    int local_count = 0;
    #pragma omp parallel for reduction(+:local_count)
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            if (array1[i] == array2[j]) {
                common_elements[local_count++] = array1[i];
                break;
            }
        }
    }
    count[thread_num] = local_count;
}

int main() {
    int array1[SIZE] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int array2[SIZE] = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
    int common_elements[SIZE];
    int count[SIZE];
    
    // Parallel computation using OpenMP
    #pragma omp parallel num_threads(2)
    {
        int thread_num = omp_get_thread_num();
        findCommonElements(array1, array2, common_elements, count, thread_num);
    }

    // Print common elements and their count
    int total_count = 0;
    printf("Common elements:\n");
    for (int i = 0; i < SIZE; i++) {
        total_count += count[i];
        for (int j = 0; j < count[i]; j++) {
            printf("%d ", common_elements[j]);
        }
    }
    printf("\nTotal common elements count: %d\n", total_count);

    return 0;
}

