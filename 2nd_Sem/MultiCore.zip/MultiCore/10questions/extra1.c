/*Write a C program that takes a filename as a command-line argument and opens the file for reading. The file contains a list of integers separated by spaces. Implement a parallelized program using OpenMP that reads these integers from the file, computes the sum of all integers, and prints the result. Ensure that file reading and sum computation are parallelized efficiently.*/

#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Error: Unable to open file %s\n", argv[1]);
        return 1;
    }

    int num, sum = 0;

    // Parallel computation using OpenMP
    #pragma omp parallel private(num) reduction(+:sum)
    {
        while (fscanf(file, "%d", &num) == 1) {
            sum += num;
        }
    }

    fclose(file);

    printf("Sum of integers in file %s: %d\n", argv[1], sum);

    return 0;
}

