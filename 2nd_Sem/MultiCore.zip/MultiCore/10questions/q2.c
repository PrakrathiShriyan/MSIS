/*2. Write a multithreaded program to add two arrays.
Create “4” threads and print the thread number with each
computation that is done.*/


#include <stdio.h>
#include <omp.h>

#define SIZE 10

void addArrays(int *array1, int *array2, int *result, int start, int end, int thread_num) {
    for (int i = start; i < end; i++) {
        result[i] = array1[i] + array2[i];
        printf("Thread %d computed result[%d]\n", thread_num, i);
    }
}

int main() {
    int array1[SIZE], array2[SIZE], result[SIZE];
    int chunk_size = SIZE / 4;

    // Initialize arrays
    for (int i = 0; i < SIZE; i++) {
        array1[i] = i;
        array2[i] = i * 2;
    }
    
    printf("Array 1:\n");
    for(int i=0; i<SIZE; i++){
    	printf("%d ",array1[i]);
    }

    printf("\n");
    printf("Array 2:\n");

    for(int i=0; i<SIZE; i++){
    	printf("%d ",array2[i]);
    }
    
    printf("\n");

    // Parallel computation using OpenMP
    #pragma omp parallel num_threads(4)
    {
        int thread_num = omp_get_thread_num();
        int start = thread_num * chunk_size;
        int end = start + chunk_size;
        
        addArrays(array1, array2, result, start, end, thread_num);
    }

    // Print the result
    printf("\nResult:\n");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", result[i]);
    }
    printf("\n");

    return 0;
}

