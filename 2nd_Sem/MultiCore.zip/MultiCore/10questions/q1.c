/*1. Write a multithreaded program to multiply every element in an array by a constant number. 
Create “4” threads and print the thread number too with the results.*/

#include <stdio.h>
#include <omp.h>
#define N 10
#define CONST 2

int main()
{
	int arr[N] = {1, 23, 9, 78, 6, 5, 4, 3, 2, 98};
	
	#pragma omp parallel num_threads(4)
	{
		int tid = omp_get_thread_num();
		#pragma omp for
		for(int i=0; i<N; i++)
		{
			arr[i] *= CONST;
			printf("Thread %d: %d\n", tid, arr[i]);
			
		}
		
	}
	return 0;
}


/*

with both #pragma: 4 threads will divide themselves the computation of product of all elements in array
Thread 2: 8
Thread 0: 2
Thread 1: 156
Thread 1: 12
Thread 1: 10
Thread 3: 4
Thread 0: 46
Thread 0: 18
Thread 2: 6
Thread 3: 196


with only 1st pragma: here 4 threads will be created and computation of product of each elements will done by individual threads separatly hence diplays 4*computation elements 
Thread 1: 2
Thread 1: 46
Thread 1: 18
Thread 1: 156
Thread 1: 12
Thread 1: 10
Thread 1: 8
Thread 1: 6
Thread 1: 4
Thread 1: 196
Thread 3: 8
Thread 3: 92
Thread 3: 36
Thread 3: 312
Thread 3: 24
Thread 3: 20
Thread 3: 16
Thread 3: 12
Thread 3: 8
Thread 3: 392
Thread 0: 4
Thread 0: 184
Thread 0: 72
Thread 0: 624
Thread 0: 48
Thread 0: 40
Thread 0: 32
Thread 0: 24
Thread 0: 16
Thread 0: 784
Thread 2: 16
Thread 2: 368
Thread 2: 144
Thread 2: 1248
Thread 2: 96
Thread 2: 80
Thread 2: 64
Thread 2: 48
Thread 2: 32
Thread 2: 1568


with only 2nd pragma: only one thread will compute the result hence prints number of elements to compute
Thread 0: 2
Thread 0: 46
Thread 0: 18
Thread 0: 156
Thread 0: 12
Thread 0: 10
Thread 0: 8
Thread 0: 6
Thread 0: 4
Thread 0: 196






