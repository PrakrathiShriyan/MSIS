/*Write a multithreaded program that will take two numbers as
input from the user, num1 and num2. The program should list out
all the numbers between 0 and num2 which are divisble by num1.
(parallelise the for loop)*/


#include <stdio.h>
#include <omp.h>

int main() {
    int num1, num2;

    printf("Enter two numbers (num1 and num2): ");
    scanf("%d %d", &num1, &num2);

    printf("Numbers between 0 and %d divisible by %d:\n", num2, num1);

    // Parallel computation using OpenMP
    #pragma omp parallel for
    /*for (int i = 0; i <= num2; i++) {*/
    for (int i = 1; i < num2; i++) {
        if (i % num1 == 0) {
            printf("%d ", i);
        }
    }
    printf("\n");

    return 0;
}

